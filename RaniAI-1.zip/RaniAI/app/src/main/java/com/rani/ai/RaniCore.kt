package com.rani.ai

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

enum class RaniState { IDLE, LISTENING, THINKING, SPEAKING }

/** App-wide brain. Lives in the process, so the UI and the wake-word service share the same Rani. */
object RaniCore {
    lateinit var prefs: Prefs
    lateinit var memory: MemoryStore
    lateinit var speech: SpeechManager
    private lateinit var executor: CommandExecutor
    private lateinit var gemini: GeminiClient
    private var ready = false

    val state = MutableStateFlow(RaniState.IDLE)
    val mood = MutableStateFlow("calm")
    val messages = MutableStateFlow<List<Msg>>(emptyList())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun init(app: Application) {
        if (ready) return
        ready = true
        prefs = Prefs(app)
        memory = MemoryStore(app)
        speech = SpeechManager(app, prefs)
        executor = CommandExecutor(app, prefs)
        gemini = GeminiClient(prefs)
        messages.value = memory.history.toList()
    }

    private fun show(m: Msg, persist: Boolean = true) {
        if (persist) memory.add(m)
        messages.value = messages.value + m
    }

    fun send(text: String) {
        if (text.isBlank()) return
        scope.launch {
            show(Msg("user", text.trim()))
            state.value = RaniState.THINKING
            try {
                val history = memory.history.filter { it.role != "system" }.takeLast(24)
                val r = gemini.chat(history, memory.facts)
                r.remember.forEach(memory::addFact)
                mood.value = r.mood
                show(Msg("model", r.reply))
                state.value = RaniState.SPEAKING
                speech.speak(r.reply, r.mood) { state.value = RaniState.IDLE }
                executor.run(r.actions).forEach { show(Msg("system", "⚙ $it"), persist = false) }
            } catch (e: Exception) {
                show(Msg("system", "⚠ ${e.message}"), persist = false)
                state.value = RaniState.IDLE
            }
        }
    }

    fun listenOnce() {
        scope.launch {
            speech.stopSpeaking()
            state.value = RaniState.LISTENING
            val heard = speech.listenOnce()
            if (heard.isNullOrBlank()) state.value = RaniState.IDLE else send(heard)
        }
    }

    fun clearMemory() { memory.clear(); messages.value = emptyList() }
}
