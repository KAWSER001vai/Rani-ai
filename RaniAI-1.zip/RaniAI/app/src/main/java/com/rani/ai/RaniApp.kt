package com.rani.ai

import android.app.Application

class RaniApp : Application() {
    override fun onCreate() {
        super.onCreate()
        RaniCore.init(this)
    }
}
