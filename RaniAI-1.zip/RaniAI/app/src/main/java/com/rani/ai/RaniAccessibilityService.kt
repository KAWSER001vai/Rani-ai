package com.rani.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Gives Rani "hands": taps, swipes, button presses by label, and global Back/Home/Recents. */
class RaniAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: RaniAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private val w get() = resources.displayMetrics.widthPixels.toFloat()
    private val h get() = resources.displayMetrics.heightPixels.toFloat()

    fun tapFraction(x: Float, y: Float) = tap(x * w, y * h)

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatch(p, 60)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 350): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatch(p, ms)
    }

    fun swipeDir(dir: String): Boolean {
        val (x1, y1, x2, y2) = when (dir) {
            "up" -> listOf(.5f, .75f, .5f, .25f)
            "down" -> listOf(.5f, .25f, .5f, .75f)
            "left" -> listOf(.85f, .5f, .15f, .5f)
            else -> listOf(.15f, .5f, .85f, .5f)
        }
        return swipe(x1 * w, y1 * h, x2 * w, y2 * h)
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                x = x.parent
            }
        }
        return false
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    private fun dispatch(path: Path, ms: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }
}
