package com.rani.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Foreground service that keeps listening for "Hey Rani ...". Android shows a persistent mic notification. */
class WakeWordService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private val wake = Regex("""\b(hey|hi|hello|ok|okay)[ ,]+(rani|ronnie|rainy)\b[ ,.!]*(.*)""", RegexOption.IGNORE_CASE)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rani_wake", "Rani listening", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rani_wake")
            .setContentTitle("Rani is listening for “Hey Rani”")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (job?.isActive != true) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        while (scope.isActive) {
            if (RaniCore.state.value != RaniState.IDLE) { delay(400); continue } // don't hear Rani's own voice
            val heard = RaniCore.speech.listenOnce()
            if (heard == null) { delay(250); continue }
            val m = wake.find(heard) ?: continue
            val cmd = m.groupValues[3].trim()
            if (cmd.isNotEmpty()) RaniCore.send(cmd) else RaniCore.listenOnce()
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
