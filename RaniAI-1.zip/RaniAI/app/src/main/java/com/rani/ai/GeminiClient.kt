package com.rani.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class RaniReply(val reply: String, val mood: String, val remember: List<String>, val actions: List<JSONObject>)

class GeminiClient(private val prefs: Prefs) {
    private val http = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()

    suspend fun chat(history: List<Msg>, facts: List<String>): RaniReply = withContext(Dispatchers.IO) {
        val key = prefs.apiKey
        if (key.isBlank()) error("Please add your Gemini API key in Settings.")

        val contents = JSONArray()
        history.dropWhile { it.role != "user" }.forEach {
            contents.put(JSONObject().put("role", it.role)
                .put("parts", JSONArray().put(JSONObject().put("text", it.text))))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(facts)))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 1.0))

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/${prefs.model}:generateContent")
            .header("x-goog-api-key", key) // header, not URL, so the key never lands in logs
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { resp ->
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
                error("Gemini error ${resp.code}: $msg")
            }
            val raw = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            parse(raw)
        }
    }

    private fun parse(raw: String): RaniReply {
        val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val o = JSONObject(clean)
            RaniReply(o.optString("reply", "…"), o.optString("mood", "calm"),
                strings(o.optJSONArray("remember")), objs(o.optJSONArray("actions")))
        } catch (e: Exception) {
            RaniReply(raw, "calm", emptyList(), emptyList())
        }
    }

    private fun strings(a: JSONArray?) = (0 until (a?.length() ?: 0)).mapNotNull { a?.optString(it)?.takeIf(String::isNotBlank) }
    private fun objs(a: JSONArray?) = (0 until (a?.length() ?: 0)).mapNotNull { a?.optJSONObject(it) }

    private fun systemPrompt(facts: List<String>) = buildString {
        appendLine(prefs.systemPrompt)
        appendLine("\nThe user likes to be called: ${prefs.nickname}.")
        if (facts.isNotEmpty()) {
            appendLine("\nLong-term memory about the user:")
            facts.forEach { appendLine("- $it") }
        }
        appendLine("\nCurrent time: ${java.util.Date()}\n")
        append(PROTOCOL) // fixed on purpose: editing the persona can't break the app
    }

    companion object {
        private const val PROTOCOL = """Reply with ONLY a JSON object (no markdown fences) in exactly this shape:
{"reply":"text shown and spoken to the user","mood":"happy|romantic|sad|excited|calm|playful|concerned","remember":["durable facts or preferences worth remembering, else empty"],"actions":[]}
Detect the user's emotion and set "mood" to the tone YOU should speak in.
"actions" controls the phone. Only add actions the user asked for. Allowed objects:
{"type":"open_app","app":"App name"}
{"type":"youtube_play","query":"song or video"}
{"type":"youtube_search","query":"..."}
{"type":"open_url","url":"https://..."}
{"type":"tap","x":0.5,"y":0.5}   (fractions of screen width/height)
{"type":"swipe","dir":"up|down|left|right"}
{"type":"click_text","text":"visible label"}
{"type":"back"} {"type":"home"} {"type":"recents"}
{"type":"termux","command":"shell command"}   (only if the user explicitly asks to run something)
Say in "reply" what you are doing. Never claim an action succeeded; the app reports failures."""
    }
}
