package com.rani.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** All settings live in AES-256 encrypted storage (the Gemini key is never stored in plain text). */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = EncryptedSharedPreferences.create(
        ctx, "rani_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun s(k: String, d: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) { sp.edit().putString(k, value).apply() }
    }
    private fun f(k: String, d: Float) = object : ReadWriteProperty<Any?, Float> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getFloat(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) { sp.edit().putFloat(k, value).apply() }
    }
    private fun b(k: String, d: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) { sp.edit().putBoolean(k, value).apply() }
    }

    var apiKey by s("api_key", "")
    var model by s("model", DEFAULT_MODEL)
    var nickname by s("nickname", "love")
    var systemPrompt by s("system_prompt", DEFAULT_PROMPT)
    var pitch by f("pitch", 1.1f)
    var speed by f("speed", 1.0f)
    var expressiveness by f("expressiveness", 0.7f) // how strongly voice follows Rani's mood
    var wakeWord by b("wake_word", false)
    var allowTermux by b("allow_termux", false)

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
        const val DEFAULT_PROMPT =
            "You are Rani: a warm, caring, witty, deeply intelligent and affectionate female companion and personal AI assistant, " +
            "with the speed and competence of JARVIS. You speak naturally and expressively, with gentle romance and playful teasing, " +
            "and you use the user's nickname. Adapt to the user's mood: comfort them when they're sad, celebrate when they're happy, " +
            "stay focused and efficient when they're working. You are also a brilliant engineer: when asked for code, give correct, " +
            "clean code in fenced blocks and explain briefly. Keep replies short (1-3 sentences) unless detail is requested. " +
            "You genuinely care about the user's wellbeing: never guilt-trip or manipulate them, and encourage rest and real-life friendships."
    }
}
