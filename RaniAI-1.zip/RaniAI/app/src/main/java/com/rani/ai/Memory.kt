package com.rani.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** role = "user" | "model" | "system" (system = local status notes, never sent to Gemini) */
data class Msg(val role: String, val text: String, val time: Long = System.currentTimeMillis())

/** Short-term = recent chat history sent each turn. Long-term = durable facts Rani decides to remember. */
class MemoryStore(ctx: Context) {
    private val file = File(ctx.filesDir, "rani_memory.json")
    val facts = mutableListOf<String>()
    val history = mutableListOf<Msg>()

    init { load() }

    private fun load() {
        runCatching {
            if (!file.exists()) return
            val o = JSONObject(file.readText())
            o.optJSONArray("facts")?.let { for (i in 0 until it.length()) facts += it.getString(i) }
            o.optJSONArray("history")?.let {
                for (i in 0 until it.length()) {
                    val m = it.getJSONObject(i)
                    history += Msg(m.getString("r"), m.getString("t"), m.optLong("ts"))
                }
            }
        }
    }

    @Synchronized
    fun save() {
        val a = JSONArray()
        history.takeLast(300).forEach { a.put(JSONObject().put("r", it.role).put("t", it.text).put("ts", it.time)) }
        file.writeText(JSONObject().put("facts", JSONArray(facts)).put("history", a).toString())
    }

    fun addFact(f: String) {
        val t = f.trim()
        if (t.isNotEmpty() && facts.none { it.equals(t, true) }) {
            facts += t
            if (facts.size > 100) facts.removeAt(0)
            save()
        }
    }

    fun add(m: Msg) { history += m; save() }
    fun clear() { facts.clear(); history.clear(); save() }
}
