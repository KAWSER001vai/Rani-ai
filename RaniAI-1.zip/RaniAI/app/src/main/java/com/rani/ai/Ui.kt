package com.rani.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Pink = Color(0xFFFF4DA6)
private val Cyan = Color(0xFF4DE1FF)
private val Violet = Color(0xFF8B5CFF)

@Composable
fun RaniTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Pink, secondary = Cyan, background = Color(0xFF0A0614), surface = Color(0xFF140B24)),
    content = content
)

@Composable
fun RaniRoot() {
    var screen by remember { mutableStateOf("home") }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) { perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)) }
    // resume hands-free mode if it was enabled
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { if (RaniCore.prefs.wakeWord) startWake(ctx) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A0614), Color(0xFF1A0B2E), Color(0xFF05121F))))) {
        if (screen == "home") HomeScreen { screen = "settings" } else SettingsScreen { screen = "home" }
    }
}

@Composable
fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.clip(shape).background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Color.White.copy(alpha = 0.16f), shape).padding(16.dp),
        content = content
    )
}

@Composable
fun Orb(state: RaniState, mood: String, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val ms = when (state) { RaniState.IDLE -> 3200; RaniState.LISTENING -> 900; RaniState.THINKING -> 1400; RaniState.SPEAKING -> 550 }
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    val rot by t.animateFloat(0f, 360f,
        infiniteRepeatable(tween(if (state == RaniState.THINKING) 1400 else 9000, easing = LinearEasing)), label = "r")
    val base = when (state) {
        RaniState.LISTENING -> Cyan
        RaniState.THINKING -> Violet
        RaniState.SPEAKING -> if (mood == "romantic") Pink else Color(0xFFFF6FB8)
        RaniState.IDLE -> Color(0xFF9D6BFF)
    }
    val amp = when (state) { RaniState.SPEAKING -> 0.18f; RaniState.LISTENING -> 0.12f; RaniState.THINKING -> 0.06f; else -> 0.04f }
    Canvas(modifier.size(280.dp)) {
        val c = center
        val r = size.minDimension / 2
        val rad = r * (0.62f + amp * pulse)
        for (i in 3 downTo 1) drawCircle(base.copy(alpha = 0.08f * i), rad * (1f + 0.18f * i), c)
        drawCircle(Brush.radialGradient(listOf(base.copy(alpha = 0.95f), base.copy(alpha = 0.35f), Color.Transparent), c, rad), rad, c)
        rotate(rot, c) {
            drawArc(Color.White.copy(alpha = 0.75f), 0f, 70f, false,
                Offset(c.x - rad * 1.12f, c.y - rad * 1.12f), Size(rad * 2.24f, rad * 2.24f),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

@Composable
fun HomeScreen(onSettings: () -> Unit) {
    val state by RaniCore.state.collectAsState()
    val mood by RaniCore.mood.collectAsState()
    val msgs by RaniCore.messages.collectAsState()
    var drawer by remember { mutableStateOf(true) }
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.lastIndex) }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column {
                Text("RANI AI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 4.sp)
                Text(when (state) {
                    RaniState.IDLE -> "Say “Hey Rani” or tap the orb"
                    RaniState.LISTENING -> "Listening…"
                    RaniState.THINKING -> "Thinking…"
                    RaniState.SPEAKING -> "Speaking · $mood"
                }, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            }
            Row {
                TextButton({ drawer = !drawer }) { Text("💬", fontSize = 20.sp) }
                TextButton(onSettings) { Text("⚙", fontSize = 20.sp) }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) {
            Orb(state, mood, Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { RaniCore.listenOnce() })
        }

        AnimatedVisibility(drawer) {
            GlassPanel(Modifier.fillMaxWidth().height(260.dp)) {
                LazyColumn(state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(msgs) { m ->
                        val speakingThis = state == RaniState.SPEAKING && m === msgs.lastOrNull { it.role == "model" }
                        Bubble(m, speakingThis)
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message Rani…") }, singleLine = true,
                shape = RoundedCornerShape(24.dp))
            TextButton({ RaniCore.listenOnce() }) { Text("🎙", fontSize = 24.sp) }
            TextButton({ RaniCore.send(input); input = "" }) { Text("➤", fontSize = 22.sp, color = Pink) }
        }
    }
}

@Composable
fun Bubble(m: Msg, speaking: Boolean) {
    when (m.role) {
        "system" -> Text(m.text, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
        else -> {
            val mine = m.role == "user"
            Row(Modifier.fillMaxWidth(), if (mine) Arrangement.End else Arrangement.Start) {
                Text(
                    (if (speaking) "🔊 " else "") + m.text, color = Color.White, fontSize = 14.sp,
                    modifier = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(16.dp))
                        .background((if (mine) Cyan else Pink).copy(alpha = 0.18f)).padding(10.dp)
                )
            }
        }
    }
}

private fun startWake(ctx: Context) {
    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
    runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java)) }
}
private fun stopWake(ctx: Context) { ctx.stopService(Intent(ctx, WakeWordService::class.java)) }

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = RaniCore.prefs
    var key by remember { mutableStateOf(p.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(p.model) }
    var nick by remember { mutableStateOf(p.nickname) }
    var prompt by remember { mutableStateOf(p.systemPrompt) }
    var pitch by remember { mutableStateOf(p.pitch) }
    var speed by remember { mutableStateOf(p.speed) }
    var expr by remember { mutableStateOf(p.expressiveness) }
    var wake by remember { mutableStateOf(p.wakeWord) }
    var termux by remember { mutableStateOf(p.allowTermux) }
    var saved by remember { mutableStateOf(false) }

    fun save() {
        p.apiKey = key.trim(); p.model = model.trim().ifBlank { Prefs.DEFAULT_MODEL }
        p.nickname = nick.trim().ifBlank { "love" }; p.systemPrompt = prompt.ifBlank { Prefs.DEFAULT_PROMPT }
        p.pitch = pitch; p.speed = speed; p.expressiveness = expr; p.wakeWord = wake; p.allowTermux = termux
        if (wake) startWake(ctx) else stopWake(ctx)
        saved = true
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("← Back") }
            Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }

        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Brain · Google Gemini", color = Cyan, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(key, { key = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton({ showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") } })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        }

        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Voice & identity", color = Cyan, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(nick, { nick = it }, Modifier.fillMaxWidth(), label = { Text("What should Rani call you?") }, singleLine = true)
            Text("Pitch  ${"%.2f".format(pitch)}"); Slider(pitch, { pitch = it }, valueRange = 0.5f..2f)
            Text("Speed  ${"%.2f".format(speed)}"); Slider(speed, { speed = it }, valueRange = 0.5f..2f)
            Text("Tone / expressiveness  ${"%.2f".format(expr)}"); Slider(expr, { expr = it }, valueRange = 0f..1f)
            OutlinedButton({ save(); RaniCore.speech.speak("Hi ${p.nickname}, this is how I sound.", "romantic") }) { Text("Test voice") }
        }

        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Personality (system prompt)", color = Cyan, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth().heightIn(min = 160.dp))
            TextButton({ prompt = Prefs.DEFAULT_PROMPT }) { Text("Reset to default") }
        }

        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Hands-free & device control", color = Cyan, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("“Hey Rani” wake word", Modifier.weight(1f)); Switch(wake, { wake = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Let Rani run Termux commands", Modifier.weight(1f)); Switch(termux, { termux = it })
            }
            Text("Accessibility: " + if (RaniAccessibilityService.instance != null) "✅ enabled" else "❌ not enabled",
                color = Color.White.copy(alpha = 0.7f))
            OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Open Accessibility settings") }
            OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Allow display over other apps") }
        }

        GlassPanel(Modifier.fillMaxWidth()) {
            Text("Memory", color = Cyan, fontWeight = FontWeight.SemiBold)
            Text("${RaniCore.memory.facts.size} long-term facts · ${RaniCore.memory.history.size} messages", color = Color.White.copy(alpha = 0.7f))
            OutlinedButton({ RaniCore.clearMemory() }) { Text("Clear all memory") }
        }

        Button({ save() }, Modifier.fillMaxWidth()) { Text(if (saved) "Saved ✓" else "Save") }
        Spacer(Modifier.height(24.dp))
    }
}
