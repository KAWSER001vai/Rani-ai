package com.rani.ai

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

/** Call every method from the main thread. */
class SpeechManager(private val ctx: Context, private val prefs: Prefs) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var pending: CancellableContinuation<String?>? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale.getDefault()
        }
    }

    fun speak(text: String, mood: String = "calm", onDone: () -> Unit = {}) {
        val t = tts
        val spoken = text.replace(Regex("```[\\s\\S]*?```"), " (I put the code in the chat) ").replace(Regex("[*_`#]"), "")
        if (t == null || !ttsReady || spoken.isBlank()) { onDone(); return }
        val (pm, sm) = when (mood) {
            "excited" -> 1.08f to 1.10f
            "playful" -> 1.05f to 1.05f
            "romantic" -> 0.97f to 0.88f
            "sad", "concerned" -> 0.95f to 0.90f
            else -> 1f to 1f
        }
        val e = prefs.expressiveness
        t.setPitch(prefs.pitch * (1 + (pm - 1) * e))
        t.setSpeechRate(prefs.speed * (1 + (sm - 1) * e))
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post(onDone) }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post(onDone) }
        })
        t.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "rani")
    }

    fun stopSpeaking() { tts?.stop() }

    /** One utterance -> text, or null on silence/error/superseded. */
    suspend fun listenOnce(): String? = suspendCancellableCoroutine { cont ->
        pending?.let { if (it.isActive) it.resume(null) }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        pending = cont
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (cont.isActive) cont.resume(t)
            }
            override fun onError(error: Int) { if (cont.isActive) cont.resume(null) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()))
        cont.invokeOnCancellation { r.destroy() }
    }
}
