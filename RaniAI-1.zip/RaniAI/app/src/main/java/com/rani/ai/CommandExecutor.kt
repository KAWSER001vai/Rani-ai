package com.rani.ai

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.delay
import org.json.JSONObject

/** Runs the "actions" Gemini returns. Returns human-readable notes for anything that didn't work. */
class CommandExecutor(private val ctx: Context, private val prefs: Prefs) {

    private val aliases = mapOf(
        "vs code" to listOf("code", "termux"), "vscode" to listOf("code", "termux"),
        "code" to listOf("termux"), "terminal" to listOf("termux"),
        "chrome" to listOf("browser"), "browser" to listOf("chrome", "internet", "firefox")
    )

    suspend fun run(actions: List<JSONObject>): List<String> {
        val notes = mutableListOf<String>()
        for (a in actions.take(6)) {
            try { exec(a)?.let(notes::add) }
            catch (e: Exception) { notes += "'${a.optString("type")}' failed: ${e.message}" }
            delay(700)
        }
        return notes
    }

    private fun launch(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private suspend fun exec(a: JSONObject): String? {
        val svc = RaniAccessibilityService.instance
        fun needSvc() = svc ?: throw IllegalStateException("enable Rani's Accessibility Service in Settings first")

        when (val type = a.optString("type")) {
            "open_app" -> {
                val n = a.getString("app")
                launch(findLaunchIntent(n) ?: return "Couldn't find an app called '$n'")
            }
            "youtube_search", "youtube_play" -> {
                val q = a.getString("query")
                try {
                    launch(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q))
                } catch (e: ActivityNotFoundException) {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
                }
                if (type == "youtube_play") {
                    if (svc == null) return "Opened YouTube search. Enable Accessibility to auto-play the first result."
                    delay(4000)                 // wait for results to load
                    svc.tapFraction(0.5f, 0.32f) // best effort: first result thumbnail
                }
            }
            "open_url" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
            "tap" -> needSvc().tapFraction(a.getDouble("x").toFloat(), a.getDouble("y").toFloat())
            "swipe" -> needSvc().swipeDir(a.getString("dir"))
            "click_text" -> if (!needSvc().clickText(a.getString("text"))) return "Couldn't find '${a.getString("text")}' on screen"
            "back" -> needSvc().back()
            "home" -> needSvc().home()
            "recents" -> needSvc().recents()
            "termux" -> {
                if (!prefs.allowTermux) return "Termux commands are switched off in Settings"
                val i = Intent("com.termux.RUN_COMMAND")
                    .setClassName("com.termux", "com.termux.app.RunCommandService")
                    .putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                    .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", a.getString("command")))
                    .putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
                ctx.startForegroundService(i)
            }
            else -> return "Unknown action '$type'"
        }
        return null
    }

    private fun findLaunchIntent(name: String): Intent? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val wanted = listOf(name) + (aliases[name.lowercase().trim()] ?: emptyList())
        for (w in wanted) {
            val lw = w.lowercase().trim()
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(lw, true) }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(lw, true) }
            if (hit != null) return pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        }
        return null
    }
}
