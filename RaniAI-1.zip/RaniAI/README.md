# Rani AI

Kotlin + Jetpack Compose Android app: Gemini-powered assistant with a warm "Rani" persona and phone control.
(Kotlin/Gradle was chosen over Kivy, so there is no requirements.txt; dependencies are in `app/build.gradle.kts`.)

## Layout
- `RaniCore.kt` brain loop (listen -> Gemini -> speak -> act), shared by UI and wake-word service
- `GeminiClient.kt` REST call; Gemini replies in JSON: reply, mood, remember[], actions[]
- `CommandExecutor.kt` app launcher, YouTube, URLs, taps/swipes, optional Termux
- `RaniAccessibilityService.kt` + `res/xml/accessibility_service_config.xml` touch automation
- `WakeWordService.kt` "Hey Rani" foreground service; `SpeechManager.kt` STT + mood-aware TTS
- `Prefs.kt` encrypted settings (API key); `Memory.kt` history + long-term facts
- `Ui.kt` glass UI, animated orb, chat drawer, settings

## Easiest build (recommended): GitHub Actions
Push this folder to a GitHub repo, open Actions > "Build APK" > download `RaniAI-debug-apk`.
Or on a PC: open in Android Studio and press Run.

## Build in Termux (works, but needs an aarch64 aapt2)
```bash
pkg update && pkg upgrade -y
pkg install -y openjdk-17 gradle git wget unzip
termux-setup-storage

# 1) Android SDK (command-line tools + platform 34 + build-tools 34.0.4).
#    Install them into ~/android-sdk (community aarch64 SDK builds exist; sdkmanager from Google is x86 only for build-tools).
export ANDROID_HOME=$HOME/android-sdk
echo "sdk.dir=$ANDROID_HOME" > local.properties

# 2) Tell Gradle to use the aarch64 aapt2: uncomment the line in gradle.properties
#    android.aapt2FromMavenOverride=/data/data/com.termux/files/home/android-sdk/build-tools/34.0.4/aapt2

# 3) Build (AGP 8.5 needs Gradle >= 8.7; check `gradle -v`)
cd ~/RaniAI
gradle assembleDebug --no-daemon
cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/RaniAI.apk
```
Then open the APK from Downloads and allow "install unknown apps".

## First run
1. Settings > paste Gemini API key (get one at aistudio.google.com) > Save.
2. Grant microphone + notifications.
3. Settings > Open Accessibility settings > Rani AI > enable (needed for taps/swipes/auto-play).
4. Settings > Allow display over other apps (lets Rani open apps in hands-free mode).
5. Turn on the "Hey Rani" switch.
6. Optional Termux: add `allow-external-apps=true` to `~/.termux/termux.properties`, run `termux-reload-settings`, grant Rani the Run Command permission, flip the Termux switch.

## Known limits
- Wake word uses Android's speech recognizer in a loop: it uses battery, may beep on some devices, and needs internet on many phones.
- `youtube_play` taps where the first result usually is; layouts vary.
- Android 14 requires hands-free mode to be started while the app is on screen (no boot auto-start).
- Not compiled or run here (no Android SDK/network in my sandbox). Expect small fixes on first build; paste any error and I'll patch it.
